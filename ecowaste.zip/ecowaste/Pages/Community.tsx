import React from "react";
import { base44 } from "../../api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Trophy, Users, Activity } from "lucide-react";

import Leaderboard from "../../Components/community/Leaderboard";
import ActivityFeed from "../../Components/community/ActivityFeed";
import CommunityStats from "../../Components/community/CommunityStats";

/* -------------------------------------
   SIMPLE CUSTOM CARD COMPONENTS
-------------------------------------- */

const Card = ({ children, className = "" }: any) => (
  <div className={`bg-white border rounded-xl shadow-sm ${className}`}>
    {children}
  </div>
);

const Tabs = ({ children }: any) => <div>{children}</div>;

const TabsList = ({ children, className = "" }: any) => (
  <div className={`flex gap-2 ${className}`}>{children}</div>
);

const TabsTrigger = ({ value, activeTab, onChange, children }: any) => (
  <button
    onClick={() => onChange(value)}
    className={`px-4 py-2 rounded-lg border 
      ${activeTab === value ? "bg-[#16A34A] text-white" : "bg-gray-100"}`}
  >
    {children}
  </button>
);

const TabsContent = ({ value, activeTab, children }: any) =>
  value === activeTab ? <div>{children}</div> : null;

/* -------------------------------------
         MAIN COMMUNITY PAGE
-------------------------------------- */

export default function Community() {
  const [activeTab, setActiveTab] = React.useState("leaderboard");

  const { data: user } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1E293B] mb-2">Community</h1>
          <p className="text-[#475569]">
            Connect with fellow eco-warriors and track our collective impact
          </p>
        </div>

        <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#16A34A] to-[#22C55E] rounded-xl text-white">
          <Users className="w-5 h-5" />
          <span className="font-semibold">Join the Movement</span>
        </div>
      </div>

      {/* Stats Section */}
      <CommunityStats />

      {/* Tabs */}
      <Tabs>
        <TabsList className="w-full max-w-md">
          <TabsTrigger
            value="leaderboard"
            activeTab={activeTab}
            onChange={setActiveTab}
          >
            <Trophy className="w-4 h-4 mr-1" /> Leaderboard
          </TabsTrigger>

          <TabsTrigger
            value="activity"
            activeTab={activeTab}
            onChange={setActiveTab}
          >
            <Activity className="w-4 h-4 mr-1" /> Activity Feed
          </TabsTrigger>
        </TabsList>

        <TabsContent value="leaderboard" activeTab={activeTab}>
          <Leaderboard currentUser={user} />
        </TabsContent>

        <TabsContent value="activity" activeTab={activeTab}>
          <ActivityFeed />
        </TabsContent>
      </Tabs>
    </div>
  );
}
