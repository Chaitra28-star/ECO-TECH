import React, { useState } from "react";
import { base44 } from "../../api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Filter } from "lucide-react";
import TaskCard from "../../Components/collect/TaskCard";
import VerificationModal from "../../Components/collect/VerificationModal";

/* --------------------------------------
   Minimal UI Components (replaces shadcn)
--------------------------------------- */

const Button = ({ children, onClick, disabled, className = "" }: any) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`px-4 py-2 rounded-md border bg-white hover:bg-gray-100 disabled:opacity-50 ${className}`}
  >
    {children}
  </button>
);

const Select = ({ value, onChange, children }: any) => (
  <select
    value={value}
    onChange={(e) => onChange(e.target.value)}
    className="border rounded-md px-3 py-2"
  >
    {children}
  </select>
);

const Option = ({ value, children }: any) => (
  <option value={value}>{children}</option>
);

/* --------------------------------------
              MAIN COMPONENT
--------------------------------------- */

export default function CollectWaste() {
  const queryClient = useQueryClient();

  const [selectedTask, setSelectedTask] = useState(null);
  const [showVerification, setShowVerification] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);

  const tasksPerPage = 6;

  const { data: tasks = [] } = useQuery({
    queryKey: ["collectionTasks"],
    queryFn: () => base44.entities.CollectionTask.list("-created_date"),
  });

  /* ------------ FILTER ------------ */
  const filteredTasks = tasks.filter(
    (task) => statusFilter === "all" || task.status === statusFilter
  );

  /* ------------ PAGINATION ------------ */
  const totalPages = Math.ceil(filteredTasks.length / tasksPerPage);
  const start = (currentPage - 1) * tasksPerPage;
  const paginatedTasks = filteredTasks.slice(start, start + tasksPerPage);

  /* ------------ HANDLE ACTION ------------ */
  const handleTaskAction = async (task: any) => {
    if (task.status === "verified" || task.status === "pending") {
      await base44.entities.CollectionTask.update(task.id, {
        status: "in_progress",
      });

      queryClient.invalidateQueries({ queryKey: ["collectionTasks"] });
    } else if (task.status === "in_progress") {
      setSelectedTask(task);
      setShowVerification(true);
    }
  };

  const handleVerificationSuccess = () => {
    setShowVerification(false);
    setSelectedTask(null);

    queryClient.invalidateQueries({ queryKey: ["collectionTasks"] });
    queryClient.invalidateQueries({ queryKey: ["userTransactions"] });
    queryClient.invalidateQueries({ queryKey: ["notifications"] });
  };

  /* ------------ UI ------------ */

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* HEADER */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#1E293B] mb-2">
            Collect Waste
          </h1>
          <p className="text-[#475569]">
            Browse verified waste sites and start collection tasks
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-[#475569]" />
          <Select value={statusFilter} onChange={setStatusFilter}>
            <Option value="all">All Tasks</Option>
            <Option value="verified">Verified</Option>
            <Option value="in_progress">In Progress</Option>
            <Option value="pending">Pending</Option>
            <Option value="completed">Completed</Option>
          </Select>
        </div>
      </div>

      {/* STATS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-md">
          <p className="text-sm text-[#475569] mb-1">Total Tasks</p>
          <p className="text-2xl font-bold text-[#1E293B]">{tasks.length}</p>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-md">
          <p className="text-sm text-[#475569] mb-1">Verified</p>
          <p className="text-2xl font-bold text-[#8B5CF6]">
            {tasks.filter((t) => t.status === "verified").length}
          </p>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-md">
          <p className="text-sm text-[#475569] mb-1">In Progress</p>
          <p className="text-2xl font-bold text-[#3B82F6]">
            {tasks.filter((t) => t.status === "in_progress").length}
          </p>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-md">
          <p className="text-sm text-[#475569] mb-1">Completed</p>
          <p className="text-2xl font-bold text-[#10B981]">
            {tasks.filter((t) => t.status === "completed").length}
          </p>
        </div>
      </div>

      {/* TASK GRID */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {paginatedTasks.map((task) => (
          <TaskCard key={task.id} task={task} onAction={handleTaskAction} />
        ))}
      </div>

      {paginatedTasks.length === 0 && (
        <div className="text-center py-16 bg-white rounded-lg shadow-md">
          <p className="text-[#475569] text-lg">
            No tasks found for the selected filter.
          </p>
        </div>
      )}

      {/* PAGINATION */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <span className="text-sm text-[#475569] px-4">
            Page {currentPage} of {totalPages}
          </span>

          <Button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* VERIFICATION MODAL */}
      <VerificationModal
        isOpen={showVerification}
        onClose={() => setShowVerification(false)}
        task={selectedTask}
        onSuccess={handleVerificationSuccess}
      />
    </div>
  );
}
