import React, { useState, useEffect } from "react";
import { base44 } from "../../api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Loader2,
  MapPin,
  Trash2,
  AlertTriangle,
  Navigation,
} from "lucide-react";
import { format } from "date-fns";

import FileUpload from "../../Components/report/FileUpload";
import VerificationResult from "../../Components/report/VerificationResult";

/* ----------------------------------------------
   CUSTOM UI COMPONENTS (replace shadcn/ui)
----------------------------------------------- */

const Card = ({ children, className = "" }) => (
  <div className={`bg-white rounded-xl border shadow-sm ${className}`}>
    {children}
  </div>
);

const CardHeader = ({ children }) => <div className="p-5 border-b">{children}</div>;
const CardTitle = ({ children, className = "" }) => (
  <h2 className={`text-lg font-semibold text-[#1E293B] flex items-center gap-2 ${className}`}>
    {children}
  </h2>
);

const CardContent = ({ children, className = "" }) => (
  <div className={`p-5 ${className}`}>{children}</div>
);

const Button = ({
  children,
  onClick,
  disabled,
  className = "",
  type = "button",
}) => (
  <button
    type={type}
    disabled={disabled}
    onClick={onClick}
    className={`px-4 py-2 rounded-lg text-white font-semibold transition 
      disabled:opacity-50 ${className}`}
  >
    {children}
  </button>
);

const Input = ({ className = "", ...props }) => (
  <input
    {...props}
    className={`border rounded-lg px-3 py-2 w-full ${className}`}
  />
);

const Label = ({ children }) => (
  <label className="text-sm font-medium text-[#1E293B]">{children}</label>
);

const Badge = ({ children, className = "" }) => (
  <span
    className={`px-2 py-1 rounded-md text-xs font-semibold capitalize ${className}`}
  >
    {children}
  </span>
);

/* TABLE COMPONENTS */
const Table = ({ children }) => <table className="w-full">{children}</table>;
const TableHeader = ({ children }) => (
  <thead className="bg-gray-100">{children}</thead>
);
const TableHead = ({ children }) => (
  <th className="text-left px-4 py-2 text-sm font-semibold text-[#1E293B]">
    {children}
  </th>
);
const TableBody = ({ children }) => <tbody>{children}</tbody>;
const TableRow = ({ children }) => <tr className="border-b">{children}</tr>;
const TableCell = ({ children, className = "" }) => (
  <td className={`px-4 py-2 text-sm text-[#475569] ${className}`}>
    {children}
  </td>
);

/* ----------------------------------------------
   MAIN COMPONENT
----------------------------------------------- */

export default function ReportWaste() {
  const queryClient = useQueryClient();

  const [selectedFile, setSelectedFile] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState(null);
  const [verificationError, setVerificationError] = useState(null);
  const [location, setLocation] = useState("");
  const [gpsLocation, setGpsLocation] = useState(null);
  const [gettingLocation, setGettingLocation] = useState(false);

  const { data: user } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: reports = [] } = useQuery({
    queryKey: ["wasteReports"],
    queryFn: () => base44.entities.WasteReport.list("-created_date", 10),
  });

  const createReportMutation = useMutation({
    mutationFn: (data) => base44.entities.WasteReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["wasteReports"] });
    },
  });

  /* ---- Auto-Get Location ---- */
  useEffect(() => {
    handleGetLocation();
  }, []);

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation not supported");
      return;
    }

    setGettingLocation(true);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const coords = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        };

        setGpsLocation(coords);

        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${coords.latitude}&lon=${coords.longitude}`
          );
          const data = await res.json();
          setLocation(data.display_name);
        } catch {
          setLocation(`${coords.latitude}, ${coords.longitude}`);
        }

        setGettingLocation(false);
      },
      () => {
        alert("Unable to access location");
        setGettingLocation(false);
      }
    );
  };

  /* ---- AI Verification ---- */
  const handleVerify = async () => {
    if (!selectedFile) return;
    if (!gpsLocation) {
      alert("Enable location services");
      return;
    }

    setVerifying(true);
    setVerificationError(null);
    setVerificationResult(null);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({
        file: selectedFile,
      });

      const aiResponse = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this image and determine if it contains waste.`,
        file_urls: [file_url],
        response_json_schema: {
          type: "object",
          properties: {
            is_waste: { type: "boolean" },
            waste_type: { type: "string" },
            quantity: { type: "number" },
            confidence_score: { type: "number" },
            analysis_notes: { type: "string" },
          },
        },
      });

      if (!aiResponse.is_waste) {
        setVerificationError("This does not appear to be waste.");
        setVerifying(false);
        return;
      }

      const result = {
        waste_type: aiResponse.waste_type || "mixed",
        quantity: Math.round(aiResponse.quantity || 20),
        confidence_score: aiResponse.confidence_score,
        image_url: file_url,
        analysis_notes: aiResponse.analysis_notes,
      };

      setVerificationResult(result);
    } catch (err) {
      setVerificationError("Failed to verify image");
    }

    setVerifying(false);
  };

  /* ---- Submit Report ---- */
  const handleSubmitReport = async () => {
    if (!verificationResult || !location || !gpsLocation) return;

    try {
      const report = await createReportMutation.mutateAsync({
        ...verificationResult,
        location,
        gps_latitude: gpsLocation.latitude,
        gps_longitude: gpsLocation.longitude,
        status: "verified",
        points_earned: 10,
      });

      await base44.entities.Transaction.create({
        user_id: user.email,
        type: "earned",
        points: 10,
        reason: "Waste Report",
        reference_id: report.id,
      });

      await base44.entities.CollectionTask.create({
        report_id: report.id,
        location,
        gps_latitude: gpsLocation.latitude,
        gps_longitude: gpsLocation.longitude,
        waste_type: verificationResult.waste_type,
        quantity: verificationResult.quantity,
        status: "verified",
        before_image_url: verificationResult.image_url,
      });

      setSelectedFile(null);
      setVerificationResult(null);
      setVerificationError(null);
    } catch {
      alert("Failed to submit report");
    }
  };

  /* ------------ STATUS COLORS ------------ */

  const statusColors = {
    verified: "bg-purple-100 text-purple-800",
    pending: "bg-yellow-100 text-yellow-800",
    in_progress: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
  };

  /* ---------------- RENDER ---------------- */

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-[#1E293B]">Report Waste</h1>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* LEFT SECTION — Upload + Verification */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>
                <Trash2 className="w-5 h-5 text-[#16A34A]" />
                Upload Waste Photo
              </CardTitle>
            </CardHeader>

            <CardContent className="space-y-4">
              <FileUpload
                onFileSelect={setSelectedFile}
                selectedFile={selectedFile}
                onClear={() => {
                  setSelectedFile(null);
                  setVerificationError(null);
                  setVerificationResult(null);
                }}
              />

              {/* Verify Button */}
              {selectedFile && !verificationResult && !verificationError && (
                <Button
                  onClick={handleVerify}
                  disabled={verifying}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {verifying ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    "Verify Waste"
                  )}
                </Button>
              )}

              {/* Error Message */}
              {verificationError && (
                <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-red-600 mb-2" />
                  <p className="text-sm text-red-800">{verificationError}</p>
                </div>
              )}

              {/* Verification Result */}
              {verificationResult && (
                <VerificationResult result={verificationResult} />
              )}
            </CardContent>
          </Card>

          {/* Report Details */}
          {verificationResult && (
            <Card>
              <CardHeader>
                <CardTitle>
                  <MapPin className="w-5 h-5 text-[#16A34A]" />
                  Report Details
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                <div>
                  <Label>Location</Label>
                  <div className="flex gap-2">
                    <Input
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />

                    <Button
                      onClick={handleGetLocation}
                      disabled={gettingLocation}
                      className="bg-gray-200 text-gray-800 hover:bg-gray-300"
                    >
                      {gettingLocation ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Navigation className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Waste Type</Label>
                    <Input disabled value={verificationResult.waste_type} />
                  </div>

                  <div>
                    <Label>Quantity (kg)</Label>
                    <Input disabled value={verificationResult.quantity} />
                  </div>
                </div>

                <Button
                  onClick={handleSubmitReport}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  Submit Report
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* RIGHT SECTION — Recent Reports */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Recent Reports</CardTitle>
            </CardHeader>

            <CardContent>
              <div className="space-y-3">
                {reports.slice(0, 5).map((r) => (
                  <div key={r.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <span className="font-semibold capitalize">
                        {r.waste_type}
                      </span>
                      <Badge className={statusColors[r.status]}>
                        {r.status}
                      </Badge>
                    </div>

                    <p className="text-xs text-[#475569]">{r.location}</p>

                    <div className="text-xs flex justify-between">
                      <span>{r.quantity} kg</span>
                      <span>{format(new Date(r.created_date), "MMM d")}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ALL REPORTS TABLE */}
      <Card>
        <CardHeader>
          <CardTitle>All Waste Reports</CardTitle>
        </CardHeader>

        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Location</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {reports.map((r) => (
                <TableRow key={r.id}>
                  <TableCell>{r.location}</TableCell>
                  <TableCell className="capitalize">{r.waste_type}</TableCell>
                  <TableCell>{r.quantity} kg</TableCell>
                  <TableCell>
                    <Badge className={statusColors[r.status]}>
                      {r.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {format(new Date(r.created_date), "MMM d, yyyy")}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
