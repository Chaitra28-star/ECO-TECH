export const base44 = {
  entities: {
    WasteReport: {
      list: async () => [],
    },
    Transaction: {
      filter: async () => [],
    },
    User: {
      list: async () => [],
    }
  }
};
