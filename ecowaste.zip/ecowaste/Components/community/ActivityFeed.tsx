import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Recycle, Gift, CheckCircle, MapPin } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";

/* -----------------------------
   TYPE DEFINITIONS
-------------------------------- */
interface User {
  email: string;
  full_name: string;
}

interface WasteReport {
  id: string;
  created_by: string;
  created_date: string;
  waste_type: string;
  quantity: number;
  location?: string;
}

interface Transaction {
  id: string;
  user_id: string;
  created_date: string;
  points: number;
  reason: string;
}

/* -----------------------------
    SAFE CUSTOM UI WRAPPERS
-------------------------------- */
const Card = ({ children, className = "" }: any) => (
  <div className={`bg-white rounded-xl border shadow-sm ${className}`}>
    {children}
  </div>
);

const CardContent = ({ children, className = "" }: any) => (
  <div className={className}>{children}</div>
);

const Avatar = ({ children, className = "" }: any) => (
  <div className={`rounded-full overflow-hidden bg-gray-200 ${className}`}>
    {children}
  </div>
);

const AvatarFallback = ({ children, className = "" }: any) => (
  <div className={`flex items-center justify-center w-full h-full ${className}`}>
    {children}
  </div>
);

/* -----------------------------
      MAIN COMPONENT
-------------------------------- */
export default function ActivityFeed() {
  /* Fetch reports */
  const { data: reports = [] } = useQuery<WasteReport[]>({
    queryKey: ["recentReports"],
    queryFn: () => base44.entities.WasteReport.list("-created_date", 20),
  });

  /* Fetch transactions */
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["recentTransactions"],
    queryFn: () =>
      base44.entities.Transaction.filter(
        { type: "earned" },
        "-created_date",
        20
      ),
  });

  /* Fetch users */
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["allUsers"],
    queryFn: () => base44.entities.User.list(),
  });

  /* ------------------ Merge Activity Feed ------------------ */
  const activities = [
    ...reports.map((r) => ({
      id: `report-${r.id}`,
      type: "report",
      user: r.created_by,
      data: r,
      date: r.created_date,
    })),
    ...transactions.map((t) => ({
      id: `transaction-${t.id}`,
      type: "earned",
      user: t.user_id,
      data: t,
      date: t.created_date,
    })),
  ].sort(
    (a, b) =>
      new Date(b.date).valueOf() - new Date(a.date).valueOf()
  );

  /* --------------------- Helper Functions ------------------- */

  const getUserName = (email: string) => {
    const user = users.find((u) => u.email === email);
    return user?.full_name || email;
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "report":
        return <Recycle className="w-5 h-5 text-[#16A34A]" />;
      case "earned":
        return <Gift className="w-5 h-5 text-[#3B82F6]" />;
      default:
        return <CheckCircle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getActivityText = (activity: any) => {
    switch (activity.type) {
      case "report":
        return (
          <span>
            reported{" "}
            <strong className="text-[#1E293B]">
              {activity.data.quantity} kg
            </strong>{" "}
            of{" "}
            <strong className="text-[#1E293B] capitalize">
              {activity.data.waste_type}
            </strong>
          </span>
        );

      case "earned":
        return (
          <span>
            earned{" "}
            <strong className="text-[#1E293B]">
              {activity.data.points} points
            </strong>{" "}
            for {activity.data.reason}
          </span>
        );

      default:
        return "performed an action";
    }
  };

  /* ------------------------- UI ----------------------------- */

  return (
    <Card className="shadow-lg">
      <CardContent className="p-6">
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100"
            >
              <Avatar className="w-10 h-10 rounded-full">
                <AvatarFallback className="bg-[#16A34A] text-white text-sm font-semibold">
                  {getUserName(activity.user).charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-semibold text-[#1E293B] truncate">
                    {getUserName(activity.user)}
                  </p>

                  <div className="flex-shrink-0">
                    {getActivityIcon(activity.type)}
                  </div>
                </div>

                <p className="text-sm text-[#475569] mb-1">
                  {getActivityText(activity)}
                </p>

                {activity.type === "report" &&
                  activity.data.location && (
                    <div className="flex items-center gap-1 text-xs text-[#475569]">
                      <MapPin className="w-3 h-3" />
                      <span>{activity.data.location}</span>
                    </div>
                  )}

                <p className="text-xs text-[#94A3B8] mt-2">
                  {formatDistanceToNow(new Date(activity.date), {
                    addSuffix: true,
                  })}
                </p>
              </div>
            </motion.div>
          ))}

          {activities.length === 0 && (
            <div className="text-center py-12 text-[#475569]">
              <Recycle className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No community activity yet. Be the first to make an impact!</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
