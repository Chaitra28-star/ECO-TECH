import React from "react";
import { MapPin, Calendar, Weight, Coins } from "lucide-react";
import { format } from "date-fns";

interface Task {
  id?: number;
  status: string;
  waste_type: string;
  location: string;
  quantity: number;
  created_date: string | Date;
  points_reward?: number;
}

interface TaskCardProps {
  task: Task;
  onAction: (t: Task) => void;
}

/* Simple reusable UI components (to replace missing UI library) */
const Card = ({ children, className = "" }: any) => (
  <div className={`bg-white rounded-xl border p-2 shadow-sm ${className}`}>
    {children}
  </div>
);

const CardContent = ({ children, className = "" }: any) => (
  <div className={className}>{children}</div>
);

const Badge = ({ children, className = "" }: any) => (
  <span className={`px-2 py-1 text-xs font-semibold rounded ${className}`}>
    {children}
  </span>
);

const Button = ({
  children,
  className = "",
  disabled,
  onClick,
}: any) => (
  <button
    className={`text-white font-semibold py-2 px-4 rounded-md transition-all duration-200 w-full ${
      disabled ? "opacity-60 cursor-not-allowed" : ""
    } ${className}`}
    onClick={onClick}
    disabled={disabled}
  >
    {children}
  </button>
);

export default function TaskCard({ task, onAction }: TaskCardProps) {
  const statusColors: any = {
    verified: { bg: "bg-purple-100", text: "text-purple-800", label: "Verified" },
    in_progress: { bg: "bg-blue-100", text: "text-blue-800", label: "In Progress" },
    pending: { bg: "bg-yellow-100", text: "text-yellow-800", label: "Pending" },
    completed: { bg: "bg-green-100", text: "text-green-800", label: "Completed" },
  };

  const status = statusColors[task.status] || statusColors.pending;

  const isAvailable =
    task.status === "verified" || task.status === "pending";

  const pointsReward =
    task.points_reward || Math.floor((task.quantity || 0) / 2) || 25;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            {/* Status + Waste type */}
            <div className="flex items-center gap-2 mb-3">
              <Badge className={`${status.bg} ${status.text} border-0`}>
                {status.label}
              </Badge>
              <span className="text-sm font-semibold text-[#1E293B] capitalize">
                {task.waste_type}
              </span>
            </div>

            {/* Location + quantity + date */}
            <div className="space-y-2">
              <div className="flex items-start gap-2 text-sm text-[#475569]">
                <MapPin className="w-4 h-4 mt-0.5 text-[#16A34A]" />
                <span>{task.location}</span>
              </div>

              <div className="flex items-center gap-4 text-sm text-[#475569]">
                <div className="flex items-center gap-1">
                  <Weight className="w-4 h-4 text-[#16A34A]" />
                  <span>{task.quantity} kg</span>
                </div>

                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4 text-[#16A34A]" />
                  <span>
                    {format(new Date(task.created_date), "MMM d, yyyy")}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Points Reward */}
          <div className="flex items-center gap-1 px-3 py-1.5 bg-amber-100 rounded-full">
            <Coins className="w-4 h-4 text-amber-600" />
            <span className="text-sm font-bold text-amber-700">
              +{pointsReward}
            </span>
          </div>
        </div>

        {/* Action Button */}
        <Button
          onClick={() => onAction(task)}
          className={
            isAvailable
              ? "bg-[#16A34A] hover:bg-[#15803D]"
              : "bg-[#3B82F6] hover:bg-[#2563EB]"
          }
          disabled={task.status === "completed"}
        >
          {isAvailable ? "Start Collection" : "Complete & Verify"}
        </Button>
      </CardContent>
    </Card>
  );
}
